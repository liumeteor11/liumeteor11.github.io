export interface Project {
  id: number;
  title: string;
  description: string;
  technologies: string[];
  link: string;
  imageUrl: string;
}

export const projects: Project[] = [
  {
    id: 5,
    title: "数据可视化仪表板",
    description: "企业级数据可视化解决方案，支持实时数据更新和自定义报表生成。",
    technologies: ["React", "TypeScript", "Recharts", "WebSocket", "Material UI"],
    link: "#",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Data%20visualization%20dashboard%20dark%20theme&sign=2faa3b9f19480dbf25c7d0a2ae696f2b"
  }
];
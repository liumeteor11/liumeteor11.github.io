import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { SocialLink, ContactInfo } from '@/types';
import { useTheme } from '@/hooks/useTheme';

export default function Footer() {
  const { theme } = useTheme();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  // Sample contact data
  const contactInfo: ContactInfo = {
    email: "contact@example.com",
    phone: "+86 123 4567 8910",
    location: "北京市海淀区"
  };
  
  // Sample social links
  const socialLinks: SocialLink[] = [
    { name: "GitHub", icon: "fa-github", url: "#" },
    { name: "LinkedIn", icon: "fa-linkedin", url: "#" },
    { name: "Twitter", icon: "fa-twitter", url: "#" },
    { name: "微信公众号", icon: "fa-weixin", url: "#" }
  ];
  
  return (
    <footer 
      id="contact" 
      className="py-10 relative z-10"
      ref={ref}
    >
      <div className={`absolute inset-0 ${
        theme === 'dark' 
          ? 'bg-gray-900/80 backdrop-blur-md' 
          : 'bg-gray-50/80 backdrop-blur-md'
      }`}></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            获取联系
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-indigo-500 to-purple-500 mx-auto rounded-full"></div>
          <p className={`mt-4 max-w-2xl mx-auto ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
            对我的工作感兴趣？请随时与我联系，讨论合作机会或技术交流。
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <h3 className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              联系方式
            </h3>
            <ul className={`space-y-3 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              <li className="flex items-start">
                <i className="fa-regular fa-envelope mt-1 mr-3 text-indigo-400"></i>
                <span>{contactInfo.email}</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-phone mt-1 mr-3 text-indigo-400"></i>
                <span>{contactInfo.phone}</span>
              </li>
              <li className="flex items-start">
                <i className="fa-regular fa-map-marker-alt mt-1 mr-3 text-indigo-400"></i>
                <span>{contactInfo.location}</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              社交媒体
            </h3>
            <ul className="space-y-3">
              {socialLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center group transition-colors ${
                      theme === 'dark' 
                        ? 'text-gray-400 hover:text-white' 
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <i className={`fa-brands ${link.icon} text-xl mr-3 text-indigo-400 group-hover:scale-110 transition-transform`}></i>
                    <span>{link.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              快速链接
            </h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="#projects"
                  className={`flex items-center transition-colors ${
                    theme === 'dark' 
                      ? 'text-gray-400 hover:text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <i className="fa-solid fa-arrow-right mr-3 text-indigo-400 group-hover:translate-x-1 transition-transform"></i>
                  项目展示
                </a>
              </li>
              <li>
                <a
                  href="#articles"
                  className={`flex items-center transition-colors ${
                    theme === 'dark' 
                      ? 'text-gray-400 hover:text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <i className="fa-solid fa-arrow-right mr-3 text-indigo-400 group-hover:translate-x-1 transition-transform"></i>
                  技术文章
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className={`flex items-center transition-colors ${
                    theme === 'dark' 
                      ? 'text-gray-400 hover:text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <i className="fa-solid fa-arrow-right mr-3 text-indigo-400 group-hover:translate-x-1 transition-transform"></i>
                  下载简历
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              订阅更新
            </h3>
            <p className={`mb-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              订阅我的通讯，获取最新的项目和文章更新。
            </p>
            <form className="space-y-3">
              <div>
                
                <input
                  type="email"
                  placeholder="您的邮箱地址"
                  className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 ${
                    theme === 'dark'
                      ? 'bg-gray-800 border border-gray-700 text-white focus:ring-indigo-500'
                      : 'bg-white border border-gray-300 text-gray-900 focus:ring-indigo-500'
                  }`}
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg text-white font-medium shadow-lg shadow-indigo-5px/20 hover:shadow-indigo-500/30 transition-all hover:-translate-y-1"
              >
                订阅
              </button>
            </form>
          </div>
        </div>
        
        <div className={`mt-16 pt-8 border-t ${
          theme === 'dark' ? 'border-gray-800' : 'border-gray-200'
        }`}>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className={`text-sm ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
              © {new Date().getFullYear()} 李明张华. 保留所有权利.
            </p>
            
            <div className={`flex space-x-6 mt-4 md:mt-0 text-sm ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
              <a href="#" className="hover:text-indigo-400 transition-colors">隐私政策</a>
              <a href="#" className="hover:text-indigo-400 transition-colors">使用条款</a>
              <a href="#" className="hover:text-indigo-400 transition-colors">Cookie 政策</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
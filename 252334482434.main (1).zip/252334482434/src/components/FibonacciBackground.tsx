import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';

// 生成斐波那契螺旋点
const generateFibonacciPoints = (count: number, size: number): {x: number, y: number, radius: number}[] => {
  const points = [];
  let a = 0, b = 1;
  
  for (let i = 0; i < count; i++) {
    const angle = i * 0.785; // 45 degrees in radians
    const radius = Math.sqrt(b) * 2;
    
    // Convert polar coordinates to Cartesian
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    
    points.push({ x, y, radius });
    
    // Next Fibonacci number
    [a, b] = [b, a + b];
  }
  
  return points;
};

export default function FibonacciBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });
  const { theme } = useTheme();
  
  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };
    
    handleResize(); // Set initial size
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size
    canvas.width = windowSize.width;
    canvas.height = windowSize.height;
    
    // Generate Fibonacci points
    const points = generateFibonacciPoints(30, Math.min(windowSize.width, windowSize.height) * 0.4);
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background gradient
    const gradient = ctx.createRadialGradient(
      canvas.width / 2, 
      canvas.height / 2, 
      0, 
      canvas.width / 2, 
      canvas.height / 2, 
      Math.max(canvas.width, canvas.height) / 1.5
    );
    
    if (theme === 'dark') {
      gradient.addColorStop(0, 'rgba(10, 10, 25, 0.8)');
      gradient.addColorStop(1, 'rgba(15, 10, 35, 1)');
    } else {
      gradient.addColorStop(0, 'rgba(245, 245, 250, 0.8)');
      gradient.addColorStop(1, 'rgba(235, 235, 245, 1)');
    }
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw Fibonacci spiral points
    points.forEach((point, index) => {
      // Position points around center with some randomness
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const x = centerX + point.x * 10;
      const y = centerY + point.y * 10;
      
      // Create gradient for each point
      const pointGradient = ctx.createRadialGradient(
        x, y, 0,
        x, y, point.radius * 2
      );
      
      if (theme === 'dark') {
        pointGradient.addColorStop(0, `rgba(99, 102, 241, ${0.3 - index * 0.01})`);
        pointGradient.addColorStop(1, 'rgba(99, 102, 241, 0)');
      } else {
        pointGradient.addColorStop(0, `rgba(79, 70, 229, ${0.2 - index * 0.005})`);
        pointGradient.addColorStop(1, 'rgba(79, 70, 229, 0)');
      }
      
      ctx.fillStyle = pointGradient;
      ctx.beginPath();
      ctx.arc(x, y, point.radius * 2, 0, Math.PI * 2);
      ctx.fill();
    });
    
    // Draw connecting lines for the spiral
    ctx.strokeStyle = theme === 'dark' ? 'rgba(165, 180, 252, 0.2)' : 'rgba(79, 70, 229, 0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    
    points.forEach((point, index) => {
      if (index === 0) return;
      
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const x = centerX + point.x * 10;
      const y = centerY + point.y * 10;
      
      if (index === 1) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });
    
    ctx.stroke();
  }, [windowSize, theme]);
  
  return (
    <div className="fixed top-2 bottom-2 left-0 right-0 z-0">
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 w-full h-full"
        aria-hidden="true"
      />
       
      {/* Decorative floating elements */}
      <AnimatePresence>
        {[1, 2, 3, 4, 5].map((id) => (
          <motion.div
            key={id}
            className={`absolute rounded-full ${
              theme === 'dark' 
                ? 'bg-indigo-500/10 backdrop-blur-sm' 
                : 'bg-indigo-100/30 backdrop-blur-sm'
            }`}
            initial={{ 
              x: Math.random() * windowSize.width, 
              y: Math.random() * windowSize.height,
              opacity: 0,
              scale: Math.random() * 0.5 + 0.5
            }}
            animate={{ 
              y: [
                windowSize.height * Math.random(),
                windowSize.height * Math.random() - 200,
                windowSize.height * Math.random()
              ],
              opacity: [0, 0.5, 0.3, 0],
              scale: [0.5, 1, 0.5]
            }}
            transition={{ 
              duration: 20 + Math.random() * 30,
              repeat: Infinity,
              repeatType: 'loop'
            }}
            style={{
              width: `${50 + Math.random() * 150}px`,
              height: `${50 + Math.random() * 150}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              transform: 'translate(-50%, -50%)'
            }}
            aria-hidden="true"
          />
        ))}
      </AnimatePresence>
      
      {/* Global Bottom Fibonacci Spiral Animation */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="absolute bottom-0 left-0 right-0 h-64 w-full flex items-center justify-center"
      >
        {/* Fibonacci spiral animation using circles with sizes following Fibonacci sequence */}
        {[1, 1, 2, 3, 5, 8, 13].map((size, index) => (
          <motion.div
            key={index}
            className="absolute rounded-full bg-indigo-500/20 backdrop-blur-sm border border-indigo-400/30"
            style={{ 
              width: `${size * 8}px`, 
              height: `${size * 8}px`,
              borderRadius: '50%'
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ 
              opacity: 0.7, 
              scale: 1,
              x: Math.cos(index * 0.8) * size * 12,
              y: Math.sin(index * 0.8) * size * 12,
              rotate: [0, 360]
            }}
            transition={{ 
              duration: 5 + index * 0.5,
              repeat: Infinity,
              repeatType: "loop",
              ease: "easeInOut"
            }}
          />
        ))}
        
        {/* Fibonacci numbers display */}
        <div className="absolute right-4 bottom-1/2 transform translate-y-1/2 flex flex-col items-center">
          {[0, 1, 1, 2, 3, 5, 8, 13, 21, 34].map((num, index) => (
            <motion.span
              key={index}
              className="text-indigo-400 font-mono text-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: 1, 
                y: 0 
              }}
              transition={{ 
                duration: 0.5,
                delay: index * 0.2,
                repeat: Infinity,
                repeatType: "reverse",
                repeatDelay: 2
              }}
            >
              {num}
            </motion.span>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
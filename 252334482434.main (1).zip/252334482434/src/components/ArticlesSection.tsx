import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { articles, Article } from '@/data/articles';
import { useTheme } from '@/hooks/useTheme';

export default function ArticlesSection() {
  const { theme } = useTheme();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };
  
  return (
    <section 
      id="articles" 
      className="py-8"
      className="py-12 relative z-10"
      ref={ref}
    >
      <div className="container mx-auto px-4 md:px-6 max-w-none">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: '0px' } : { opacity: 0, y: '20px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            技术文章
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-indigo-500 to-purple-500 mx-auto rounded-full"></div>
          <p className={`mt-4 max-w-2xl mx-auto ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
            分享我的技术见解与经验，涵盖前端开发、设计趋势与用户体验优化。
          </p>
        </motion.div>
        
        <motion.div
          variants={container}
          initial="hidden"
          animate={isInView ? "show" : "hidden"}
          className="w-full"
        >
          {articles.map((article) => (
            <motion.article
              key={article.id}
              variants={item}
              className={`mb-8 last:mb-0 p-6 rounded-xl transition-all duration-300 hover:shadow-lg ${
                theme === 'dark'
                  ? 'bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 hover:border-indigo-500/30'
                  : 'bg-white/80 backdrop-blur-sm border border-gray-200 hover:border-indigo-100'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
                <h3 className={`text-xl md:text-2xl font-bold group-hover:text-indigo-400 transition-colors ${
                  theme === 'dark' ? 'text-white' : 'text-gray-900'
                }`}>
                  <a href={article.link} className="inline-block">
                    {article.title}
                  </a>
                </h3>
                
                <div className={`flex items-center text-sm ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
                  <time dateTime={article.date} className="flex items-center">
                    <i className="fa-regular fa-calendar mr-2"></i> {article.date}
                  </time>
                  <span className="mx-2">•</span>
                  <span className="flex items-center">
                    <i className="fa-regular fa-clock mr-2"></i> {article.readTime}
                  </span>
                </div>
              </div>
              
              <p className={`mb-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                {article.summary}
              </p>
              
              <a
                href={article.link}
                className={`inline-flex items-center font-medium group ${
                  theme === 'dark' ? 'text-indigo-400 hover:text-indigo-300' : 'text-indigo-600 hover:text-indigo-700'
                }`}
              >
                阅读全文
                <i className="fa-solid fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
              </a>
            </motion.article>
          ))}
          
          <motion.div
            variants={item}
            className="text-center mt-12"
          >
            <a
              href="#"
              className={`inline-flex items-center px-6 py-3 rounded-lg font-medium transition-all hover:-translate-y-1 ${
                theme === 'dark'
                  ? 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              查看所有文章 <i className="fa-solid fa-newspaper ml-2"></i>
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>);
}
export interface SocialLink {
  name: string;
  icon: string;
  url: string;
}

export interface ContactInfo {
  email: string;
  phone: string;
  location: string;
}
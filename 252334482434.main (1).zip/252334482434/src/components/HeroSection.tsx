import { motion } from 'framer-motion';
import { useState } from 'react';
import { useTheme } from '@/hooks/useTheme';

export default function HeroSection() {
  const { theme } = useTheme();
  
  // 头像切换功能
  const [currentAvatar, setCurrentAvatar] = useState(0);
  const avatars = [
    "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Professional%20portrait%20of%20a%20software%20engineer%20in%20modern%20style&sign=a6b13f40b45e5015a7f5951a544452b6",
    "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Portrait%20of%20a%20creative%20designer%20in%20modern%20style&sign=69e2a84beee27e65337434b7749719f1"
  ];
  
  const handleAvatarClick = () => {
    setCurrentAvatar(prev => (prev + 1) % avatars.length);
  };
  
  return (
      <section id="hero" className="relative pt-20 pb-16">
          <div className="px-0 relative z-10 w-full h-full">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start justify-items-center w-full">
          {/* Profile Image */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
              className="flex justify-start"
          >
            <div className="relative">
              {/* Fibonacci-inspired circular pattern */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500/20 to-purple-500/20 blur-2xl animate-pulse"></div>
              
               <div className="relative w-48 h-48 md:w-56 md:h-56 rounded-full overflow-hidden border-4 border-white/10 backdrop-blur-sm shadow-xl cursor-pointer transform transition-transform hover:scale-105">
                <img
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Professional%20portrait%20of%20a%20software%20engineer%20in%20modern%20style&sign=a6b13f40b45e5015a7f5951a544452b6"
                  alt="个人头像"
                  className="w-full h-full object-cover"
                />
                
                {/* Decorative Fibonacci elements around profile */}
                <div className="absolute -top-2 -right-2 w-12 h-12 rounded-full bg-gradient-to-r from-indigo-400 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
                  1.618
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Profile Information */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="space-y-6">
              <div>
                <h1 className={`text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight ${
                  theme === 'dark' ? 'text-white' : 'text-gray-900'
                }`}>
                  李明 <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-500">张华</span>
                </h1>
                <p className="mt-2 text-xl md:text-2xl text-gray-400">
                  高级前端工程师 & UI设计师
                </p>
              </div>
              
              <div className={`space-y-3 text-lg ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                <p className="flex items-start">
                  <span className="text-indigo-400 mr-2">•</span>
                  专注于创建美观且高性能的Web应用，拥有7年前端开发经验。
                </p>
                <p className="flex items-start">
                  <span className="text-indigo-400 mr-2">•</span>
                  热衷于将数学美学与现代设计原则相结合，创造独特的用户体验。
                </p>
                <p className="flex items-start">
                  <span className="text-indigo-400 mr-2">•</span>
                  擅长React、TypeScript和响应式设计，致力于构建无障碍且用户友好的数字产品。
                </p>
              </div>
              
              <div className="flex flex-wrap gap-3 pt-4">
                <a
                  href="#projects"
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg text-white font-medium shadow-lg shadow-indigo-5px/20 hover:shadow-indigo-500/30 transition-all hover:-translate-y-1"
                >
                  查看我的项目
                </a>
                <a
                  href="#contact"
                  className={`px-6 py-3 rounded-lg font-medium transition-all hover:-translate-y-1 ${
                    theme === 'dark'
                      ? 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`} 
                >
                  联系我
                </a>
         </div>
         </div>
          </motion.div>
       </div>
       

        </div>
      
    </section>
  );
}
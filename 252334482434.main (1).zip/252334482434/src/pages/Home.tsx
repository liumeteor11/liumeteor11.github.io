import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import ProjectsSection from '@/components/ProjectsSection';
import ArticlesSection from '@/components/ArticlesSection';
import Footer from '@/components/Footer';
import FibonacciBackground from '@/components/FibonacciBackground';
import { useTheme } from '@/hooks/useTheme';

export default function Home() {
  const { theme } = useTheme();
  
  // Set document title
  useEffect(() => {
    document.title = '李明张华 | 高级前端工程师 & UI设计师';
  }, []);
  
  // Navigation sections
  const sections = ['首页', '项目', '文章', '联系'];
  
  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      {/* Fibonacci background */}
      <FibonacciBackground />
      
      {/* Navigation */}
      <Navbar sections={sections} />
            
      {/* Main content */}
      <main>
        <HeroSection />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 px-4">
          <ProjectsSection />
          <ArticlesSection />
        </div>
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  ); 
}
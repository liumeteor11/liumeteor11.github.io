export interface Article {
  id: number;
  title: string;
  summary: string;
  date: string;
  readTime: string;
  link: string;
}

export const articles: Article[] = [
  {
    id: 1,
    title: "深入理解斐波那契数列在UI设计中的应用",
    summary: "探索黄金比例如何影响视觉设计，以及如何在界面设计中应用斐波那契数列创造更和谐的布局。",
    date: "2025-08-15",
    readTime: "8 分钟",
    link: "#"
  },
  {
    id: 2,
    title: "现代前端开发中的状态管理策略",
    summary: "比较不同的状态管理方案，从Context API到Redux，分析各自的优缺点和适用场景。",
    date: "2025-07-22",
    readTime: "12 分钟",
    link: "#"
  },
  {
    id: 3,
    title: "构建高性能React应用的10个技巧",
    summary: "从组件优化到代码分割，分享提升React应用性能的实用技巧和最佳实践。",
    date: "2025-06-30",
    readTime: "10 分钟",
    link: "#"
  },
  {
    id: 4,
    title: "深色模式设计指南：美学与可用性的平衡",
    summary: "探讨深色模式的设计原则，如何确保可读性同时创造视觉吸引力，以及实现深色/浅色模式切换的技术方案。",
    date: "2025-05-18",
    readTime: "15 分钟",
    link: "#"
  }
];